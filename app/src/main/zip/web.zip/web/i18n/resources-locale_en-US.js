{    
	"_AppTitle_": "cMO",
	
	"_FootMenuHome_": "Home",
	"_FootMenuWork_": "Work",
	"_FootMenuDirectory_": "Directory",
	"_FootMenuMy_": "My",
	
	"_QuickLaunchVote_": "Vote",
	"_QuickLaunchHolidayBooking_": "Holiday booking",
	"_QuickLaunchNew_": "New",
	
	"_OfficeNews_": "Office News",
	
	"_NextButton_": "Next",
	"_Logon_": "Log on",
	"_PlaceHolderUserName_": "Username",
	"_PlaceHolderPassword_": "Password",
	"_SignIn_": "Sign In",
	"_NameRequiredMsg_": "Your username is required!",
	"_PswdRequiredMsg_": "Your password is required!",
	"_ErrorMsg_": "Your email or password is not correct!",
	
	"_Vote_": "Vote",
	"_My_": "My"

}