var app = angular.module('app', ['ngRoute', 'ngAnimate', 'localization', 'ui.bootstrap']).config(
	["$routeProvider", function($routeProvider){
		$routeProvider.
			when('/', {templateUrl: 'views/home.html', controller: 'HomeController'}).
			when('/login', {templateUrl: 'views/login.html', controller: 'LoginController'}).
			when('/register', {templateUrl: 'views/register.html', controller: 'RegisterController'}).
			when('/password', {templateUrl: 'views/reset_password.html', controller: 'ResetPasswordController'}).
			when('/user/:id', {templateUrl: 'views/userInfo.html', controller: 'userInfoController'}).
			when('/news/:id', {templateUrl: 'views/news_detail.html', controller: 'NewsDetailController'}).
			when('/voted/:id', {templateUrl: 'views/voted.html', controller: 'VotedDetailController'}).
			when('/votes',{templateUrl:'views/vote.html',controller:'VoteController'}).
			when('/account',{templateUrl:'views/account.html',controller:'AccountController'}).            
			when('/voteInfo',{templateUrl:'views/voteInfo.html',controller:'VoteController'}).
			otherwise({redirectTo: '/'});
	}]
).config(function($sceProvider){
	$sceProvider.enabled(false);
});

var useDummy = true;
var prefix = "http://localhost:8081/HyTE-Java/ws/";

var mround = function(r){
	return r >> 0;
}

