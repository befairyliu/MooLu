app.factory("authenticationService", ["$http", function($http){

	var promise;
	var service = {

		login: function(params){
			if(useDummy){
				promise = $http.get("dummy/login.json?t=" + (new Date().getTime())).then(function(response){					
					return response.data;
				});
			}
			else{
				//for testing the token api
				params = {client_id:"mobile-client",client_secret:"mobile",grant_type:"password",scope:"read write",username:"user",password:"user"};
				//end
				promise = $http({				
					method: 'POST',
					url: "http://localhost:8080/HyTE-Java/oauth/token",
					data: params,
					headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
				}).then(function(response){
					console.log("login response.access_token>>>>>>>>>>>>>>>>>>>", response.data.access_token);
					return response.data;
				});				
			}
			return promise;

		},
		register: function(fn,ln,em,ps){
			if(useDummy){
				promise = $http.get("dummy/register.json").then(function(response){
					//dummy data, the structure is different with real data.
					return response.data.result;
				});
				return promise;
			}
			else{				
				promise = $http({				
					method: 'POST',
					url: "../ws/employeerole/updateEmployeeRole/",
					data: empRole,
					headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
				}).then(function(response){
					return response.data;
				});				
				return promise;
			}
		}
	}
	return service;
}]);

app.factory("userInfoService", ["$http", function($http){
	var promise;
	var service = {
		getUserInfoById: function(id,token){
			if(useDummy){
				promise = $http.get("dummy/userinfo.json?t=" + (new Date().getTime())).then(function(response){	
					console.log("response>>>>>>>>>>>>>>>>>>",response.data);
					return response.data;
				});
			}
			else{
				promise = $http({				
					method: 'GET',
					url: prefix+"user/getuserinfo",
					data: {},
					headers: {'Authorization': 'bearer'+token}
				}).then(function(response){
					console.log("userInfo response>>>>>>>>>>>>>>>>>>>");
					return response.data;
				});	
			}
			return promise;
		},
		getUserActivitiesById: function(id,token){
			if(useDummy){
				promise = $http.get("dummy/useractivities.json?t=" + (new Date().getTime())).then(function(response){	
					console.log("getUserActivitiesById response>>>>>>>>>>>>>>>>>>",response.data);
					return response.data;
				});
			}
			else{
				promise = $http({				
					method: 'GET',
					url: prefix+"user/getuserinfo",
					data: {},
					headers: {'Authorization': 'bearer'+token}
				}).then(function(response){
					console.log("userInfo response>>>>>>>>>>>>>>>>>>>");
					return response.data;
				});	
			}
			return promise;
		}
	}
	return service;
}]);

app.factory("articleService", ["$http", function($http){
	var promise;
	var service = {
		getNews: function(){
			if(useDummy){
				promise = $http.get("dummy/news.json?t=" + (new Date().getTime())).then(function(response){
					return response.data;
				});
				return promise;
			}
			else{				
				promise = $http.get("dummy/news.json?t=" + (new Date().getTime())).then(function(response){
					return response.data;
				});
				return promise;
			}
		},
		getNewsById: function(id){
			if(useDummy){
				promise = $http.get("dummy/news.json?t=" + (new Date().getTime())).then(function(response){
					var article = {};
					for(var i=0;i<response.data.result.news.length;i++){
						if(response.data.result.news[i].id == id){
							article = response.data.result.news[i];
							return article;
						}
					}
					return article;
				});
				return promise;
			}
			else{				
				promise = $http.get("dummy/news.json?t=" + (new Date().getTime())).then(function(response){
					var article = {};
					for(var i=0;i<response.data.result.news.length;i++){
						if(response.data.result.news[i].id == id){
							article = response.data.result.news[i];
							return article;
						}
					}
					return article;
				});
				return promise;
			}
		},
		getBanners: function(){
			if(useDummy){
				promise = $http.get("dummy/flash_banner.json?t=" + (new Date().getTime())).then(function(response){
					return response.data.result;
				});
				return promise;
			}
			else{				
				promise = $http.get("dummy/flash_banner.json?t=" + (new Date().getTime())).then(function(response){
					return response.data.result;
				});
				return promise;
			}
		},
	}
	return service;
}]);


// to simulate jquery ajax
app.config(function($httpProvider) {
    $httpProvider.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded';
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
 
    // Override $http service's default transformRequest
    $httpProvider.defaults.transformRequest = [function(data) {
        /**
         * The workhorse; converts an object to x-www-form-urlencoded serialization.
         * @param {Object} obj
         * @return {String}
         */
        var param = function(obj) {
            var query = '';
            var name, value, fullSubName, subName, subValue, innerObj, i;
 
            for (name in obj) {
                value = obj[name];
 
                if (value instanceof Array) {
                    for (i = 0; i < value.length; ++i) {
                        subValue = value[i];
                        fullSubName = name + '[' + i + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if (value instanceof Object) {
                    for (subName in value) {
                        subValue = value[subName];
                        fullSubName = name + '[' + subName + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if (value !== undefined && value !== null) {
                    query += encodeURIComponent(name) + '='
                            + encodeURIComponent(value) + '&';
                }
            }
 
            return query.length ? query.substr(0, query.length - 1) : query;
        };
 
        return angular.isObject(data) && String(data) !== '[object File]'
                ? param(data)
                : data;
    }];
});

app.factory("voteService", ["$http", function($http){
	var promise;
	var service = {
		getVotes: function(){
			if(useDummy){
				promise = $http.get("dummy/votes.json?t=" + (new Date().getTime())).then(function(response){
					return response.data;
				});
				return promise;
			}
			else{				
				promise = $http({				
					method: 'POST',
					url: "../ws/employeerole/updateEmployeeRole/",
					data: empRole,
					headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
				}).then(function(response){
					return response.data;
				});				
				return promise;
			}
		},
		getVotesById: function(id){
			if(useDummy){
				promise = $http.get("dummy/votes.json?t=" + (new Date().getTime())).then(function(response){
console.log(response.data.result.votes);
				return response.data.result.votes[id];
				});
				return promise;
			}
			else{				
				promise = $http({				
					method: 'POST',
					url: "../ws/employeerole/updateEmployeeRole/",
					data: empRole,
					headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
				}).then(function(response){
					return response.data;
				});				
				return promise;
			}
		}
	}
	return service;
}]);


app.factory("voteDataService", ["$http", function($http){
    var promise;
    var service = {
        getVotes: function(){
            if(useDummy){
                promise = $http.get("dummy/votedatas.json?t=" + (new Date().getTime())).then(function(response){
                    return response.data;
                });
                return promise;
            }
            else{
            	 promise = $http.get("dummy/votedatas.json?t=" + (new Date().getTime())).then(function(response){
                     return response.data;
                 });
                 return promise;
            }
        }
    }
    return service;
}]);


// localization module
angular.module('localization', []).factory('localize', ['$http', '$rootScope', '$window', '$filter', function ($http, $rootScope, $window, $filter) {
	var substitute = function(str, sub) {
		return str.replace(/\{(.+?)\}/g, function($0, $1) {
			return $1 in sub ? sub[$1] : $0;
		});
	};

    var localize = {
        language:$window.navigator.userLanguage || $window.navigator.language,
        dictionary:{},
        resourceFileLoaded:false,

        successCallback:function (data) {
            localize.dictionary = data;
            localize.resourceFileLoaded = true;
            $rootScope.$broadcast('localizeResourcesUpdates');
        },

        initLocalizedResources:function () {

            var url = 'i18n/resources-locale_' + localize.language + '.js';
            $http({ method:"GET", url:url, cache:false }).success(localize.successCallback).error(function () {
				// default language en-US
                var url = 'i18n/resources-locale_en-US.js';
                $http({ method:"GET", url:url, cache:false }).success(localize.successCallback);
				
            });
        },

        getLocalizedString:function (value, options) {
            var result = '';
            if (!localize.resourceFileLoaded) {
                localize.initLocalizedResources();
                localize.resourceFileLoaded = true;
                return result;
            }
            if (localize.dictionary) {
				var entry = localize.dictionary[value];
                if ((entry !== null) && (entry != undefined)) {
                    result = entry;
					if(options){
						result = substitute(entry, options);
					}
                }
				
            }
            return result;
        }
    };
    return localize;
} ]).
    filter('i18n', ['localize', function (localize) {
    return function (input, options) {
        return localize.getLocalizedString(input, options);
    };
}]);