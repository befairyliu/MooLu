app.controller("HeaderController", ['$scope', '$rootScope', function($scope, $rootScope){
	$rootScope.titleLocaleKey = "_AppTitle_";
	$rootScope.canAddVote = false;
    $scope.logo = "lib/image/logo.png";
    $scope.back = function(){
    	$rootScope.canAddVote = false;
		history.back();
	};
	$scope.attemptToAddVote = function(){
		$rootScope.$broadcast('ADD_VOTE_EVENT');	
	}
}]);

app.controller("FooterController", ['$location', '$scope', function($scope, $location){
	
}]);

app.controller("HomeController", ['$scope', "$rootScope", "authenticationService", function($scope, $rootScope, authenticationService){
	
	$scope.pageClass = "page-home";
	$rootScope.withoutFooter = false;
	$rootScope.canAddVote = false;
	$rootScope.titleLocaleKey = '_AppTitle_';
	$rootScope.hideBackButton = true;
	$rootScope.isLoggedIn = false;
	// try login api
}]);

app.controller("LoginController", ['$location', '$scope', "$rootScope", "authenticationService", function($location, $scope, $rootScope, authenticationService){

	$scope.pageClass = "page-login";
	$rootScope.hideBackButton = false;
	
	$rootScope.withoutFooter = true;
	/*$scope.currentStep = 1;
	$scope.finishedStep = 0;*/	
	
}]);


app.controller("AccountController", ['$location', '$scope', "$rootScope", "$routeParams", "userInfoService", function($location, $scope, $rootScope, $routeParams, userInfoService){

	$scope.pageClass = "page-user-info";
	$rootScope.withoutFooter = false;
	$rootScope.canAddVote = false;
	//userInfoService.getUserInfoById($routeParams.id).then(function(data){
		//$scope.userInfo = data;
	//});
}]);


app.controller("userInfoController", ['$location', '$scope', "$rootScope", "$routeParams", "userInfoService", function($location, $scope, $rootScope, $routeParams, userInfoService){

	$scope.pageClass = "page-user-info";
	$rootScope.titleLocaleKey = "_My_";
	$rootScope.withoutFooter = true;
	$rootScope.scrollDisabled = true;
	$rootScope.canAddVote = false;
	//console.log("userInfoController token from logon>>>>>>",$rootScope.token);
	userInfoService.getUserInfoById($routeParams.id,$rootScope.token).then(function(data){
		$scope.userInfo = data;
		userInfoService.getUserActivitiesById($routeParams.id,$rootScope.token).then(function(data){
			$scope.userActivities = data.result.activities;
			console.log("getUserActivitiesById controller data>>>>>>>>>>>>>>",$scope.userActivities);
		});
	});
}]);

app.controller("RegisterController", ['$scope', "$rootScope", function($scope, $rootScope){

	$scope.pageClass = "page-register";
}]);


app.controller("ResetPasswordController", ['$scope', "$rootScope", function($scope, $rootScope){

	$scope.pageClass = "page-reset-password";
}]);


app.controller("NewsDetailController", ['$scope', "$rootScope", "$routeParams", "articleService", function($scope, $rootScope, $routeParams, articleService){
	$scope.pageClass = "page-news-detail";
	$rootScope.canAddVote = false;
	articleService.getNewsById($routeParams.id).then(function(data){
		$scope.article = data;
	});
}]);


//add by liu
app.controller("VoteController",['$scope','$rootScope','$routeParams','voteDataService',function($scope, $rootScope, $routeParams, voteDataService){
    $scope.pageClass = "";
    $scope.infourl = "";
	$rootScope.titleLocaleKey = "_Vote_";
	$rootScope.hideBackButton = false;
	$rootScope.canAddVote = true;

    console.log("Hello the controller is.....");
    //get votes info from service...
    voteDataService.getVotes().then(function(data){
        $scope.tabs = data.votes;
        console.log("The tabs....."+ $scope.tabs);
    });

    $scope.back = function(){
        history.back();
    };

    $scope.voteInfo = function(){
       
        $scope.infourl = "#/voteInfo";

        console.log("The vote information url is ...... "+$scope.infourl);
    };
    
    
    $rootScope.$on("ADD_VOTE_EVENT", function(event){
    	console.log("handle ADD_VOTE_EVENT...")
    	
    })


    /*$scope.tabs = [
        {
            "id":0,
            "title":"Voting",
            "contents":[
                {"id":0,"subject":"Color Run0","voter":"Jane Zhang", "time":"2h53min"},
                {"id":1,"subject":"Color Run1","voter":"Jane Zhang", "time":"2h53min"},
                {"id":8,"subject":"Color Run8","voter":"Jane Zhang", "time":"2h53min"},
                {"id":9,"subject":"Color Run9","voter":"Jane Zhang", "time":"2h53min"},
                {"id":10,"subject":"Color Run10","voter":"Jane Zhang", "time":"2h53min"},
                {"id":2,"subject":"Color Run2","voter":"Jane Zhang", "time":"2h53min"},
                {"id":3,"subject":"Color Run3","voter":"Jane Zhang", "time":"2h53min"},
                {"id":4,"subject":"Color Run4","voter":"Jane Zhang", "time":"2h53min"},
                {"id":5,"subject":"Color Run5","voter":"Jane Zhang", "time":"2h53min"},
                {"id":6,"subject":"Color Run6","voter":"Jane Zhang", "time":"2h53min"},
                {"id":7,"subject":"Color Run7","voter":"Jane Zhang", "time":"2h53min"},
                {"id":11,"subject":"Color Run11","voter":"Jane Zhang", "time":"2h53min"}
            ]
        },
        {
            "id":1,
            "title":"Voted",
            "contents":[
                {"id":0,"subject":"ChiFan","voter":"Susuan Liang", "time":"2h53min"},
                {"id":1,"subject":"ChiFan","voter":"Susuan Liang", "time":"2h53min"},
                {"id":2,"subject":"ChiFan","voter":"Susuan Liang", "time":"2h53min"},
                {"id":3,"subject":"ChiFan","voter":"Susuan Liang", "time":"2h53min"}
            ]
        },
        {
            "id":2,
            "title":"My",
            "contents":[
                {"id":0,"subject":"Color Run","voter":"Jane Zhang", "time":"2h53min"},
                {"id":1,"subject":"Color Run","voter":"Jane Zhang", "time":"2h53min"},
                {"id":2,"subject":"Color Run","voter":"Jane Zhang", "time":"2h53min"},
                {"id":3,"subject":"Color Run","voter":"Jane Zhang", "time":"2h53min"}
            ]
        }
    ]*/

}]);


app.controller("VotedDetailController", ['$scope', "$rootScope", "$routeParams", "voteService", function($scope, $rootScope, $routeParams, voteService){
	$scope.pageClass = "page-votes-detail";
	$rootScope.hideBackButton = false;
	voteService.getVotesById($routeParams.id).then(function(data){
		$scope.vote = data;
	});
}]);

