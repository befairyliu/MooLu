
app.directive('hyteHeader', function($window){
	return {
		restrict: "E",
		replace: true,
		templateUrl: "views/tmpl_header.html",
		link: function(scope, element, attrs){
		
		}
	}
});

app.directive('hyteFooter', function(){
	return {
		restrict: "E",
		replace: true,
		templateUrl: "views/tmpl_footer.html"
	}
});

app.directive('hyteSlider', function(articleService){
	return {
		restrict: "E",
		replace: true,
		templateUrl: "views/tmpl_slider.html",
		link: function(scope, element, attrs){
			articleService.getBanners().then(function(result){
				scope.slides = result.banners;
				var sw = window.screen.width;
				var indicator = document.querySelector('.indicator');
				scope.indicatorWidth = scope.slides.length * 20 -10;
				scope.scrollerWidth = scope.slides.length * sw;
				scope.slideWidth = sw;
		
				setTimeout(function(){
					var myScroll = new IScroll(document.querySelector('.swipe-view'), {
						scrollX: true,
						scrollY: false,
						momentum: false,
						snap: true,
						snapSpeed: 400,
						keyBindings: true,				
						indicators: {
							el: indicator,
							resize: false
						}
					});
				},50);
			});
			
		}
	}
});





app.directive('hyteQuickLaunch', function(){
	return {
		restrict: "E",
		replace: true,
		templateUrl: "views/tmpl_quick_launch.html"
	}
});

app.directive('hyteNews', function($location, articleService){
	return {
		restrict: "E",
		replace: true,
		templateUrl: "views/tmpl_news.html",
		link: function(scope, element, attrs){
			articleService.getNews().then(function(data){
				scope.news = data.result.news;
			});
			
		}
	}
});

app.directive('hyteLogin', function($location, $rootScope, $http, authenticationService){
	return {
		restrict: "E",
		replace: true,
		templateUrl: "views/tmpl_login.html",
		link: function(scope, element, attrs){
			var username, password;
			scope.signIn = function(isValid){
				username = LogonForm.username.value,
				password = LogonForm.password.value;
				scope.LogonForm.submitted = false;
				if(isValid){
					
					var param = {j_username:username,j_password:password};
					console.log("params ", param);
					//$http.defaults.useXDomain = true;
					authenticationService.login(param).then(function(data){
						console.log(data)
						if(useDummy){
							scope.hasError = false;
							$location.path("/user/"+data.userId);
							$rootScope.isLoggedIn = true;
							
							return true;
						}
						
						else{
							if(data.access_token){
								console.log("success");
								$rootScope.isLoggedIn = true;
								$rootScope.token = data.access_token;
								//for testing
								$location.path("/user/1");
								//$location.path("/account");
							}
							else{
								console.log("failed");
							}
							console.log("data.access_token>>>>>>>>>>>>>>>>>>",data.access_token);
						}
						/*if(data && data.Logonflag == '1' ){				
							$rootScope.isLoggedIn = true;
							scope.hasError = false;
							authenticationService.login(username,password).then(function(data){
								//$rootScope.userInfo.empNo = data;
								$rootScope.userInfo = {
									empNo: data
									
								};
								$location.path("/user/"+data.userId);
							});
						}*/
					});
					scope.hasError = false;
					scope.LogonForm.submitted = true;
				}
				else if(username.$error.required || password.$error.required){
					scope.hasError = true;
					scope.LogonForm.submitted = true;
				}
				
			}
		}
	}
});

app.directive("backButton", function(){
	return {
	      restrict: 'A',
	      link: function(scope, element, attrs) {
	        element.bind('click', goBack);

	        function goBack() {
	          history.back();
	          scope.$apply();
	        }
	      }
	    }
});

app.directive("datePicker", function(){
	return {
		restrict: "EA",
		replace: true,
		template: '<input type="text" placeholder="{{placeHolder}}" required="required"/>',
		link: function(scope, element, attrs){
			scope.placeHolder = attrs.placeholder || "";

			element.bind("touchend", function(){
				element.attr("type","date");
				element[0].focus();
			});
			element.bind("blur", function(){
				element.attr("type","text");
			});
		}
	}
})


app.directive("adjacent", function(){
	return {
		restrict: "EA",
		replace: true,
		transclude: true,
		scope: {
			direction: '@',
			onAdjacent: '&'
			//onNext: '&'
		},
		template: "<div ng-transclude ng-click='onAdjacent(evt)' class='adjacent {{direction}} '></div>",
		link: function(scope, element, attrs){
			var dir = attrs.direction.toLowerCase() == "next"?1:-1;
			function adjacentTo(){
			}
			//element.bind('click', adjacentTo);
		},
		controller: function($scope) {}
	}
});

app.directive("whatIsIt", function( $rootScope ){
	return {
		restrict: "A",
		link: function(scope, element, attrs){
			function openDialog() {
				$rootScope.showHelpPane = true;
				$rootScope.$apply();
			};			
			element.bind('click', openDialog);
		}
	}
});


app.directive("helpPane", function($rootScope){
	return {
		restrict: "EA",
		replace: true,
		templateUrl: 'views/tmpl_whatisit.html',
		link: function(scope, element, attrs){
			function closeDialog(){
				$rootScope.showHelpPane = false;
				if(!$rootScope.$$phase) {
					$rootScope.$apply();
				}
			}
			element.bind('click', closeDialog);
			var el = element[0];
			//if(isIE8Browser()){
			$rootScope.$watch('sheetPos', function(newVal){	
				// for the shit of ie8			
				if(!newVal || !newVal.x)
					return;
				angular.element(el.querySelector('.horizontalRuler')).css({
					"left": newVal.x + "px",
					top: (newVal.y+10) + "px",
					width: newVal.w + "px"
				});
				
				angular.element(el.querySelector('.verticalRuler')).css({
					left:(newVal.x < 32 ? newVal.x: newVal.x - 32) + 'px',
					top: (newVal.y + 92) + 'px',
					height: '76px'
				});
			
				angular.element(el.querySelector('.verticalArrow')).css({
					left:(newVal.x < 32?newVal.x: newVal.x - 32) + 'px',
					top: (newVal.y + 180) + 'px',
					height: '400px'
				});				
				
				angular.element(el.querySelector('.helpInfo')).css({
					left:(newVal.x + 50)+'px',
					width: (newVal.w - 100) + "px",
					top:(newVal.y + newVal.h/3)+'px'
				});		
								
			});
			//}
			scope.$on('$destroy', function (){
				// destroy radar chart
				$rootScope.sheetPos = null;
			});
		}
	}
});

app.directive("careerItem", function( $modal, $log, careerItemService){
	return {
		restrict: "A",
		link: function(scope, element, attrs){
			function openDialog() {
				if(element.attr("clickable") != "true")
					return;
				var modalInstance = $modal.open({
					templateUrl: 'views/tmpl_modal.html',
					controller: ModalInstanceCtrl,
					size: 'lg',
					resolve: {
						career: function () {							
							return element.attr('data-career');
						}
					}
				})
			};			
			element.bind('click', openDialog);
		}
	}
});

app.directive('bindHtmlUnsafe', function( $compile ) {
    return function( $scope, $element, $attrs ) {
        var compile = function( newHTML ) {
            newHTML = $compile(newHTML)($scope);
            $element.html('').append(newHTML); 
        };
        var htmlName = $attrs.bindHtmlUnsafe; 
        $scope.$watch(htmlName, function( newHTML ) { 
            if(!newHTML) return;
            compile(newHTML); 
        });
    };
});

app.directive("radarChart", function(){
	return {
		restrict: "EA",
		replace: true,
		template: "<canvas height='650' width='650'></canvas>",

		link: function(scope, element){
			var itemName = element.attr("data-src");
			var radar;
			
			scope.$parent.hasCanvas = isCanvasSupported();
			scope.$parent.$$phase || scope.$parent.$apply();
			scope.$watch('$parent.' + itemName, function(newVal){				
				if(newVal){
					var data = scope.$parent[itemName];
					if(isCanvasSupported()){
						radar = new Chart(element[0].getContext("2d")).Radar(data,{scaleShowLabels : false, pointLabelFontSize : 12, scaleFontSize: 12});
					}
				}
			});
			scope.$on('$destroy', function (){
				// destroy radar chart
				radar = null;
			});
		}
	}
});

/*
this code is used for fixing the conflicting issue between ngAnimation and bootstrap carousel
*/
app.directive('setNgAnimate', ['$animate', function ($animate) {
    return {
        link: function ($scope, $element, $attrs) {
            $scope.$watch( function() {
                return $scope.$eval($attrs.setNgAnimate, $scope);
            }, function(valnew, valold){
                console.log('Directive animation Enabled: ' + valnew);
                $animate.enabled(!!valnew, $element);
            });
        }
    };
}]);


app.directive('tuborVote', function(){
	console.log("The tubor vote is.......");
    return {
        restrict: "EA",
        replace: true,
        templateUrl: 'views/tmpl_vote.html',
        /*link: function(scope, element, attrs){
            element.bind("click",function(){
            	console.log("The click is.....");
            	attrs.href= "#/voteInfo";
            });
        }*/
    };
});

app.directive("hyteSwipe", function($location, $rootScope, $http){
	var startX,startY,endY;
	return {
		restrict: "E",
		replace: true,
		templateUrl: "views/tmpl_swipe.html",
		link: function(scope, element, attrs){
			var swipeToggle = element.find("a");
			swipeToggle.bind("touchstart",function(){
				console.log("touchstart>>>>>>>>>>>>>>>>>>>");
				event.preventDefault();
				if (!event.touches.length) return;
			    var touch = event.touches[0];
			    startX = touch.pageX;
			    startY = touch.pageY;
			  //  element.css("top",startY + "px");
			});
			
			swipeToggle.bind("touchmove",function(){
				event.preventDefault();
			    if (!event.touches.length) return;
			    var touch = event.touches[0];
			    endY = touch.pageY;
			    element.css("top",touch.pageY + "px");
			});
			
			swipeToggle.bind("touchend",function(){
				 var y = endY - startY;
				 //Swipe from bottom to top
				 if(y<0){
					 //Todo:Animation
					 // element.addClass("swipe-bottom-top");
					 $rootScope.withoutFooter = false;
					 $rootScope.withoutHeader = true;
					 console.log("$rootScope.withoutFooter>>>>",$rootScope.withoutFooter);
					 $rootScope.$apply();
					 element.css('top','0px');
				 }
				 //Swipe from top to bottom
				 else{
					 //Todo:Animation
					// element.addClass("swipe-top-bottom");
					 $rootScope.withoutFooter = true;
					 $rootScope.withoutHeader = false;
					 console.log("else $rootScope.withoutFooter>>>>",$rootScope.withoutFooter);
					 $rootScope.$apply();
					 element.css('top','93%');
				 }
			});
			
		}
	};
});

